#负责各个功能函数的定义和实现
#目标功能：显示菜单 新建名片 显示全部名片 查询名片 修改名片 删除名片
card_list=[]
def showmenu():
    print()
    print()
    print('*'*50)
    print('欢迎使用 [名片管理】 v1.0')
    print()
    print('1. 新建名片')
    print('2. 显示全部')
    print('3. 查询名片')
    print()
    print('0. 退出系统')
    print('*' * 50)
#新建名片     ，涉及到查询等等，最好是列表里存字典，为了方便所有函数，最好定义全局变量
def new_card():
    print('[功能]新建名片')
    username=input('请输入姓名：')
    mobileohone=input('请输入电话：')
    qq=input('请输入QQ号码：')
    email=input('请输入邮箱：')
    card={'姓名':username,'电话':mobileohone,'QQ号':qq,'邮箱':email}
    card_list.append(card)#使用append把字典作为一个整体加入列表
    print('新建姓名是：{}'.format(username)+' 名片成功')  #get取key值时一定记得''成对引号
#显示全部
new_card()
def see_all():
    print('[功能]显示全部')
    i=1
    print('-'*50)
    for i in card_list:
        n=1
        for n in i:
            print(' {}\t\t'.format(n),end='')
        print()
    print('-' * 50)
    #遍历card_list
    for m in card_list:
        for key,vals in m.items():
            print(' {}\t\t'.format(vals),end='')


see_all()
#查询名片
def search():
    print('查询全部')
#退出系统
def exit():
    print('退出系统')